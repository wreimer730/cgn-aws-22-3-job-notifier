import json
import boto3
import requests

mybucket = "testbucket-wladmir-reimer-202211061828"
url = "https://www.arbeitnow.com/api/job-board-api"

def get_data(url):
    response = requests.get(url)
    job_data = response.json()
    return job_data

def upload_data(jsondata, bucket_name):
    s3 = boto3.client('s3')
    for job in jsondata["data"]:
        s3.put_object(Body=json.dumps(job), Bucket=bucket_name, Key=job["slug"]+ ".json")

def empty_bucket(bucket_name):
    bucket = boto3.resource('s3').Bucket(bucket_name)
    bucket.objects.all().delete()

def lambda_handler(event, context): 
    ### main section
    empty_bucket(mybucket)
    upload_data(get_data(url),mybucket)